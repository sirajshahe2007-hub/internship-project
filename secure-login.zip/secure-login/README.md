# Keyhold: Secure Login System

A small Flask web app with registration, login, sessions, logout and optional
TOTP two-factor authentication (2FA).

## Run it

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export SECRET_KEY=$(python -c "import secrets; print(secrets.token_hex(32))")
python app.py            # http://127.0.0.1:5000
pytest                   # run the test suite (20 tests)
```

Windows PowerShell: `$env:SECRET_KEY = python -c "import secrets; print(secrets.token_hex(32))"`

## Requirement checklist

| Requirement | Where / how |
|---|---|
| Registration and login with hashed passwords | `argon2-cffi` (Argon2id). Hashes are salted automatically and upgraded on login if parameters change. |
| Input validation | Username/email regex, password length (10-128) and complexity, common-password and username checks, request size cap. Validated server-side; HTML attributes are only hints. |
| SQL injection protection | Every query uses `?` placeholders. No SQL is built from user input. Tested with injection payloads. |
| Session management and logout | Cookie holds a random token; only its SHA-256 is stored server-side. Logout deletes the row, so a stolen cookie stops working. 30-minute idle and 8-hour absolute timeouts. New token on every login (prevents fixation). Cookie is `HttpOnly`, `SameSite=Lax`, and `Secure` when `COOKIE_SECURE=1`. |
| Optional 2FA | TOTP (RFC 6238) with QR setup, works with any authenticator app. Secrets are encrypted at rest (Fernet). Used codes can't be replayed. 8 single-use recovery codes. Turning 2FA off requires the password. |

## Extra hardening

- CSRF tokens on every form (Flask-WTF)
- Account lockout after 5 failed attempts (15 min), including wrong 2FA codes
- Per-IP throttling of failed attempts
- Same generic error for unknown user and wrong password; Argon2 runs even for unknown users to even out timing
- Security headers: CSP, `X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Cache-Control: no-store`
- Jinja2 auto-escaping prevents XSS in rendered values

## Before deploying for real

1. Serve over HTTPS and set `COOKIE_SECURE=1`; add HSTS at the proxy.
2. Set a fixed, secret `SECRET_KEY`. It also derives the key that encrypts 2FA secrets, so changing it invalidates enrolled 2FA.
3. Run behind a proper WSGI server (gunicorn/waitress), not `app.run`.
4. The per-IP throttle is in memory and per process. Use Redis (e.g. Flask-Limiter) for multiple workers, and `ProxyFix` if behind a proxy.
5. Registration tells a visitor when a username/email is taken. Add email verification if that matters for your threat model.
6. Add password reset and email verification flows (not included).

## Layout

```
app.py              routes, security logic, DB schema
templates/          Jinja2 pages
static/style.css    styling (light and dark)
tests/test_app.py   pytest suite
```
