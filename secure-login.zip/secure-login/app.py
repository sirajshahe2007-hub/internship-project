"""Secure login system: Flask + SQLite + Argon2 + TOTP 2FA.

Security features (see README for details):
  * Argon2id password hashing, transparent rehash on login
  * Parameterized SQL only (no string-built queries)
  * Server-side validation of every input
  * Server-side sessions: logout really invalidates the session
  * CSRF protection on every POST
  * Account lockout + per-IP throttling, generic error messages
  * Optional TOTP 2FA with replay protection and recovery codes
  * Strict security headers (CSP, frame denial, no-store)
"""
import base64
import hashlib
import hmac
import io
import os
import re
import secrets
import sqlite3
import time
from collections import defaultdict, deque
from functools import wraps

import pyotp
import qrcode
import qrcode.image.svg
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from cryptography.fernet import Fernet, InvalidToken
from flask import (Flask, flash, g, redirect, render_template, request,
                   session, url_for)
from flask_wtf.csrf import CSRFProtect
from markupsafe import Markup

# --------------------------------------------------------------------------
# Tunables
# --------------------------------------------------------------------------
MAX_FAILED_ATTEMPTS = 5          # per account, before lockout
LOCKOUT_SECONDS = 15 * 60
IP_LIMIT, IP_WINDOW = 20, 10 * 60  # failed attempts per IP per window
SESSION_IDLE_SECONDS = 30 * 60
SESSION_ABSOLUTE_SECONDS = 8 * 60 * 60
PENDING_2FA_SECONDS = 5 * 60
MIN_PASSWORD, MAX_PASSWORD = 10, 128

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")
COMMON_PASSWORDS = {
    "password123", "1234567890", "qwerty12345", "letmein1234",
    "welcome1234", "iloveyou123", "admin123456", "password1234",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email           TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash   TEXT NOT NULL,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    INTEGER NOT NULL DEFAULT 0,
    totp_secret     TEXT,
    totp_enabled    INTEGER NOT NULL DEFAULT 0,
    last_totp_step  INTEGER NOT NULL DEFAULT 0,
    created_at      INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL,
    last_seen  INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS recovery_codes (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code_hash TEXT NOT NULL,
    used      INTEGER NOT NULL DEFAULT 0
);
"""

ph = PasswordHasher()  # Argon2id with library defaults
# Verified against when the user doesn't exist, so response time doesn't
# reveal whether an account exists.
DUMMY_HASH = ph.hash("dummy-password-for-timing-equalisation")


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def create_app(test_config=None):
    app = Flask(__name__)
    secret = os.environ.get("SECRET_KEY")
    if not secret:
        secret = secrets.token_hex(32)
        print("WARNING: SECRET_KEY not set; using a random key for this run.")
    app.config.update(
        SECRET_KEY=secret,
        DATABASE=os.environ.get("DATABASE", "app.db"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=SESSION_ABSOLUTE_SECONDS,
        MAX_CONTENT_LENGTH=16 * 1024,  # forms are tiny; reject big bodies
    )
    if test_config:
        app.config.update(test_config)

    CSRFProtect(app)
    ip_attempts = defaultdict(deque)  # in-memory; use Redis for multi-process
    fernet = Fernet(base64.urlsafe_b64encode(
        hashlib.sha256(("totp:" + app.config["SECRET_KEY"]).encode()).digest()))

    # ---------------------------------------------------------------- DB ---
    def db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys = ON")
        return g.db

    @app.teardown_appcontext
    def close_db(_exc):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    with app.app_context():
        db().executescript(SCHEMA)
        db().commit()

    # ----------------------------------------------------------- helpers ---
    def validate_registration(username, email, password, confirm):
        errors = []
        if not USERNAME_RE.fullmatch(username):
            errors.append("Username must be 3-30 characters: letters, numbers, underscore.")
        if len(email) > 254 or not EMAIL_RE.fullmatch(email):
            errors.append("Enter a valid email address.")
        if not MIN_PASSWORD <= len(password) <= MAX_PASSWORD:
            errors.append(f"Password must be {MIN_PASSWORD}-{MAX_PASSWORD} characters.")
        else:
            if not (re.search(r"[a-z]", password) and re.search(r"[A-Z]", password)
                    and re.search(r"\d", password)):
                errors.append("Password needs an uppercase letter, a lowercase letter and a number.")
            if password.lower() in COMMON_PASSWORDS or (
                    username and username.lower() in password.lower()):
                errors.append("Password is too easy to guess. Avoid common words and your username.")
        if password != confirm:
            errors.append("Passwords do not match.")
        return errors

    def ip_limited():
        q, now = ip_attempts[request.remote_addr], time.time()
        while q and now - q[0] > IP_WINDOW:
            q.popleft()
        return len(q) >= IP_LIMIT

    def ip_fail():
        ip_attempts[request.remote_addr].append(time.time())

    def record_failure(user):
        ip_fail()
        if user is None:
            return
        attempts = user["failed_attempts"] + 1
        locked = int(time.time()) + LOCKOUT_SECONDS if attempts >= MAX_FAILED_ATTEMPTS else 0
        db().execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?",
                     (0 if locked else attempts, locked, user["id"]))
        db().commit()

    def start_session(user_id):
        session.clear()  # new identifier on login: prevents session fixation
        token = secrets.token_urlsafe(32)
        now = int(time.time())
        db().execute("INSERT INTO sessions VALUES (?,?,?,?,?)",
                     (sha256(token), user_id, now, now, now + SESSION_ABSOLUTE_SECONDS))
        db().commit()
        session["sid"] = token  # only the random token lives in the cookie
        session.permanent = True

    def encrypt(s):
        return fernet.encrypt(s.encode()).decode()

    def decrypt(s):
        try:
            return fernet.decrypt(s.encode()).decode()
        except InvalidToken:
            return None

    def verify_totp(user, code):
        """Return the matched time step, or None. Steps already used are rejected."""
        secret_ = decrypt(user["totp_secret"] or "")
        if not secret_ or not re.fullmatch(r"\d{6}", code):
            return None
        totp, now_step = pyotp.TOTP(secret_), int(time.time() // 30)
        for step in (now_step - 1, now_step, now_step + 1):
            if step > user["last_totp_step"] and hmac.compare_digest(totp.at(step * 30), code):
                return step
        return None

    def use_recovery_code(user, code):
        code = re.sub(r"[\s-]", "", code.lower())
        cur = db().execute(
            "UPDATE recovery_codes SET used=1 WHERE user_id=? AND code_hash=? AND used=0",
            (user["id"], sha256(code)))
        db().commit()
        return cur.rowcount == 1

    def new_recovery_codes(user_id, n=8):
        db().execute("DELETE FROM recovery_codes WHERE user_id=?", (user_id,))
        codes = []
        for _ in range(n):
            raw = secrets.token_hex(5)
            codes.append(f"{raw[:5]}-{raw[5:]}")
            db().execute("INSERT INTO recovery_codes (user_id, code_hash) VALUES (?,?)",
                         (user_id, sha256(raw)))
        db().commit()
        return codes

    def qr_svg(uri):
        img = qrcode.make(uri, image_factory=qrcode.image.svg.SvgPathImage, box_size=10)
        buf = io.BytesIO()
        img.save(buf)
        svg = buf.getvalue().decode()
        return Markup(svg[svg.index("<svg"):])

    def login_required(view):
        @wraps(view)
        def wrapped(*a, **kw):
            if g.user is None:
                flash("Sign in to continue.", "info")
                return redirect(url_for("login"))
            return view(*a, **kw)
        return wrapped

    # ------------------------------------------------- request lifecycle ---
    @app.before_request
    def load_user():
        g.user = None
        token = session.get("sid")
        if not token:
            return
        row = db().execute(
            "SELECT s.token_hash, s.last_seen, s.expires_at, u.* FROM sessions s "
            "JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?",
            (sha256(token),)).fetchone()
        now = int(time.time())
        if (row is None or row["expires_at"] < now
                or now - row["last_seen"] > SESSION_IDLE_SECONDS):
            if row is not None:
                db().execute("DELETE FROM sessions WHERE token_hash=?", (row["token_hash"],))
                db().commit()
            session.clear()
            return
        if now - row["last_seen"] > 60:
            db().execute("UPDATE sessions SET last_seen=? WHERE token_hash=?",
                         (now, row["token_hash"]))
            db().commit()
        g.user = row

    @app.after_request
    def security_headers(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data:; style-src 'self'; "
            "form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    # ------------------------------------------------------------ routes ---
    @app.get("/")
    def index():
        return redirect(url_for("dashboard" if g.user else "login"))

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if g.user:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            email = request.form.get("email", "").strip()
            password = request.form.get("password", "")
            confirm = request.form.get("confirm", "")
            errors = validate_registration(username, email, password, confirm)
            if not errors:
                try:
                    db().execute(
                        "INSERT INTO users (username, email, password_hash, created_at) "
                        "VALUES (?,?,?,?)",
                        (username, email, ph.hash(password), int(time.time())))
                    db().commit()
                except sqlite3.IntegrityError:
                    errors.append("That username or email is already registered.")
            if errors:
                for e in errors:
                    flash(e, "error")
                return render_template("register.html", username=username, email=email), 400
            flash("Account created. Sign in to continue.", "success")
            return redirect(url_for("login"))
        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            ident = request.form.get("identifier", "").strip()[:254]
            password = request.form.get("password", "")[:MAX_PASSWORD]
            if ip_limited():
                flash("Too many attempts. Try again in a few minutes.", "error")
                return render_template("login.html"), 429
            user = db().execute(
                "SELECT * FROM users WHERE username = ? OR email = ?", (ident, ident)).fetchone()
            now = int(time.time())
            locked = bool(user and user["locked_until"] > now)
            try:
                ph.verify(user["password_hash"] if user else DUMMY_HASH, password)
                password_ok = user is not None
            except (VerificationError, InvalidHashError):
                password_ok = False
            if not password_ok or locked:
                if not locked:
                    record_failure(user)
                flash("Invalid credentials, or the account is temporarily locked.", "error")
                return render_template("login.html", identifier=ident), 401

            db().execute("UPDATE users SET failed_attempts=0, locked_until=0 WHERE id=?",
                         (user["id"],))
            if ph.check_needs_rehash(user["password_hash"]):
                db().execute("UPDATE users SET password_hash=? WHERE id=?",
                             (ph.hash(password), user["id"]))
            db().commit()
            if user["totp_enabled"]:
                session.clear()
                session["pending_user"] = user["id"]
                session["pending_at"] = now
                return redirect(url_for("verify_2fa"))
            start_session(user["id"])
            return redirect(url_for("dashboard"))
        return render_template("login.html")

    @app.route("/login/2fa", methods=["GET", "POST"])
    def verify_2fa():
        uid, started = session.get("pending_user"), session.get("pending_at", 0)
        if not uid or time.time() - started > PENDING_2FA_SECONDS:
            session.clear()
            flash("Sign in again to continue.", "info")
            return redirect(url_for("login"))
        if request.method == "POST":
            if ip_limited():
                flash("Too many attempts. Try again in a few minutes.", "error")
                return render_template("verify_2fa.html"), 429
            user = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
            code = request.form.get("code", "").strip()[:32]
            if user is None or user["locked_until"] > time.time():
                session.clear()
                return redirect(url_for("login"))
            step = verify_totp(user, code)
            if step is not None:
                db().execute("UPDATE users SET last_totp_step=? WHERE id=?", (step, uid))
                db().commit()
            elif not use_recovery_code(user, code):
                record_failure(user)  # code guesses count toward lockout
                flash("That code didn't work. Check your authenticator app and try again.", "error")
                return render_template("verify_2fa.html"), 401
            start_session(uid)
            return redirect(url_for("dashboard"))
        return render_template("verify_2fa.html")

    @app.post("/logout")
    def logout():
        token = session.get("sid")
        if token:
            db().execute("DELETE FROM sessions WHERE token_hash=?", (sha256(token),))
            db().commit()
        session.clear()
        flash("You have been signed out.", "success")
        return redirect(url_for("login"))

    @app.get("/dashboard")
    @login_required
    def dashboard():
        return render_template("dashboard.html")

    @app.route("/2fa/setup", methods=["GET", "POST"])
    @login_required
    def setup_2fa():
        user = g.user
        if user["totp_enabled"]:
            return redirect(url_for("dashboard"))
        if not user["totp_secret"]:
            db().execute("UPDATE users SET totp_secret=? WHERE id=?",
                         (encrypt(pyotp.random_base32()), user["id"]))
            db().commit()
            user = db().execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
        secret_ = decrypt(user["totp_secret"])
        if request.method == "POST":
            step = verify_totp(user, request.form.get("code", "").strip())
            if step is None:
                flash("That code didn't match. Try the current code from your app.", "error")
            else:
                db().execute("UPDATE users SET totp_enabled=1, last_totp_step=? WHERE id=?",
                             (step, user["id"]))
                db().commit()
                return render_template("recovery_codes.html",
                                       codes=new_recovery_codes(user["id"]))
        uri = pyotp.TOTP(secret_).provisioning_uri(name=user["email"], issuer_name="Keyhold")
        return render_template("setup_2fa.html", qr=qr_svg(uri), secret=secret_)

    @app.post("/2fa/disable")
    @login_required
    def disable_2fa():
        try:
            ph.verify(g.user["password_hash"], request.form.get("password", "")[:MAX_PASSWORD])
        except (VerificationError, InvalidHashError):
            ip_fail()
            flash("Password incorrect. Two-factor authentication is still on.", "error")
            return redirect(url_for("dashboard"))
        db().execute("UPDATE users SET totp_enabled=0, totp_secret=NULL, last_totp_step=0 "
                     "WHERE id=?", (g.user["id"],))
        db().execute("DELETE FROM recovery_codes WHERE user_id=?", (g.user["id"],))
        db().commit()
        flash("Two-factor authentication is off.", "success")
        return redirect(url_for("dashboard"))

    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000)
