import base64
import hashlib
import re
import sqlite3
import time

import pyotp
import pytest

from app import MAX_FAILED_ATTEMPTS, create_app

PW = "Correct-Horse-9"


@pytest.fixture()
def app(tmp_path):
    return create_app({"TESTING": True, "WTF_CSRF_ENABLED": False,
                       "SECRET_KEY": "test-secret", "DATABASE": str(tmp_path / "t.db")})


@pytest.fixture()
def client(app):
    return app.test_client()


def register(c, username="alice", email="alice@example.com", pw=PW, confirm=None):
    return c.post("/register", data={"username": username, "email": email,
                                     "password": pw, "confirm": confirm or pw})


def login(c, ident="alice", pw=PW):
    return c.post("/login", data={"identifier": ident, "password": pw})


def get_secret(page):
    return re.search(rb'class="secret">([A-Z2-7]+)<', page.data).group(1).decode()


def test_register_login_logout(client):
    assert register(client).status_code == 302
    assert login(client).headers["Location"].endswith("/dashboard")
    assert b"Hello, alice" in client.get("/dashboard").data
    client.post("/logout")
    assert client.get("/dashboard").status_code == 302


def test_password_is_hashed_with_argon2(client, app):
    register(client)
    row = sqlite3.connect(app.config["DATABASE"]).execute(
        "SELECT password_hash FROM users").fetchone()
    assert row[0].startswith("$argon2id$") and PW not in row[0]


@pytest.mark.parametrize("pw", ["short1A", "alllowercase123", "NOLOWERCASE123",
                                "NoDigitsHereAtAll", "alice-Pass-123"])
def test_weak_passwords_rejected(client, pw):
    assert register(client, pw=pw).status_code == 400


def test_bad_username_and_email_rejected(client):
    assert register(client, username="bad name!").status_code == 400
    assert register(client, email="not-an-email").status_code == 400


def test_duplicate_user_rejected(client):
    register(client)
    assert register(client, email="other@example.com").status_code == 400


@pytest.mark.parametrize("payload", ["' OR '1'='1", "alice'--", "'; DROP TABLE users;--"])
def test_sql_injection_does_not_bypass_login(client, payload):
    register(client)
    assert login(client, ident=payload, pw=payload).status_code == 401
    assert login(client, ident=payload, pw=PW).status_code == 401
    assert login(client).status_code == 302  # table still intact


def test_generic_error_for_unknown_user_and_bad_password(client):
    register(client)
    def norm(resp, name):
        body = re.sub(rb'name="csrf_token" value="[^"]+"', b"", resp.data)
        return body.replace(name, b"X")

    client.get("/login")  # consume the one-time "Account created" flash
    a = login(client, "alice", "wrong-Password1")
    b = login(client, "nobody", "wrong-Password1")
    assert a.status_code == b.status_code == 401
    assert norm(a, b"alice") == norm(b, b"nobody")


def test_account_lockout(client):
    register(client)
    for _ in range(MAX_FAILED_ATTEMPTS):
        login(client, pw="wrong-Password1")
    assert login(client).status_code == 401  # correct password, but locked


def test_logout_invalidates_server_side_session(client):
    register(client)
    login(client)
    with client.session_transaction() as s:
        stolen = dict(s)
    client.post("/logout")
    with client.session_transaction() as s:
        s.update(stolen)  # attacker replays the old cookie
    assert client.get("/dashboard").status_code == 302


def test_dashboard_requires_login(client):
    assert client.get("/dashboard").status_code == 302


def test_security_headers(client):
    h = client.get("/login").headers
    assert "frame-ancestors 'none'" in h["Content-Security-Policy"]
    assert h["X-Content-Type-Options"] == "nosniff" and h["Cache-Control"] == "no-store"


def test_csrf_enforced(tmp_path):
    app = create_app({"TESTING": True, "SECRET_KEY": "k", "DATABASE": str(tmp_path / "c.db")})
    c = app.test_client()
    assert c.post("/login", data={"identifier": "a", "password": "b"}).status_code == 400
    page = c.get("/login").data.decode()
    token = re.search(r'name="csrf_token" value="([^"]+)"', page).group(1)
    r = c.post("/login", data={"identifier": "a", "password": "b", "csrf_token": token})
    assert r.status_code == 401  # passed CSRF, failed auth


def test_two_factor_flow(client, app):
    register(client)
    login(client)
    secret = get_secret(client.get("/2fa/setup"))
    totp = pyotp.TOTP(secret)
    assert client.post("/2fa/setup", data={"code": "000000"}).status_code == 200
    ok = client.post("/2fa/setup", data={"code": totp.now()})
    assert b"recovery codes" in ok.data.lower()
    codes = re.findall(rb"[0-9a-f]{5}-[0-9a-f]{5}", ok.data)
    assert len(codes) == 8

    stored = sqlite3.connect(app.config["DATABASE"]).execute(
        "SELECT totp_secret FROM users").fetchone()[0]
    assert secret not in stored  # encrypted at rest

    client.post("/logout")
    assert login(client).headers["Location"].endswith("/login/2fa")
    assert client.get("/dashboard").status_code == 302  # password alone is not enough

    assert client.post("/login/2fa", data={"code": "123456"}).status_code == 401
    assert client.post("/login/2fa", data={"code": totp.now()}).status_code == 401  # replay

    nxt = totp.at(time.time() + 30)
    assert client.post("/login/2fa", data={"code": nxt}).status_code == 302
    assert b"Hello, alice" in client.get("/dashboard").data

    client.post("/logout")
    login(client)
    code = codes[0].decode()
    assert client.post("/login/2fa", data={"code": code}).status_code == 302
    client.post("/logout")
    login(client)
    assert client.post("/login/2fa", data={"code": code}).status_code == 401  # single use


def test_disable_2fa_needs_password(client):
    register(client)
    login(client)
    secret = get_secret(client.get("/2fa/setup"))
    client.post("/2fa/setup", data={"code": pyotp.TOTP(secret).now()})
    client.post("/2fa/disable", data={"password": "wrong-Password1"})
    assert b"On" in client.get("/dashboard").data
    client.post("/2fa/disable", data={"password": PW})
    assert b"Off" in client.get("/dashboard").data
