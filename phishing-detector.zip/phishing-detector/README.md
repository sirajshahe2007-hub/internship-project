# Phishing Email Detection (scikit-learn)

Classifies an email as **Phishing** or **Safe** using its text and URL features, and reports
accuracy, a classification report, and a confusion matrix.

## Quick start
```bash
pip install -r requirements.txt
python generate_dataset.py        # creates data/emails.csv (synthetic demo data)
python train.py                   # trains, evaluates, saves model + confusion matrix
python predict.py --text "Your account is suspended. Verify: http://paypal-login.top/x"
```

## How it works
| Stage | Details |
|---|---|
| Text features | TF-IDF on unigrams + bigrams (`TfidfVectorizer`) |
| URL features | URL count, IP-address links, URL shorteners, suspicious TLDs, `@` in URL, URL length, subdomain depth, hyphens, brand-in-domain, non-HTTPS ratio |
| Keyword features | urgency, credential-request and money/prize word counts, exclamations, uppercase ratio |
| Models | Logistic Regression vs Random Forest, chosen by 5-fold CV on the **training split only** |
| Evaluation | Held-out 20% test set: accuracy, precision/recall/F1, confusion matrix (`outputs/confusion_matrix.png`) |

All features and the classifier live in one sklearn `Pipeline`, so there is no train/test leakage
and the saved model accepts raw email text.

## Using a real dataset (important)
`data/emails.csv` is **synthetic and template-based**, so the accuracy it produces demonstrates the
pipeline, not real-world performance. For meaningful results, use a real corpus with `text,label`
columns, e.g. the Kaggle "Phishing Email Dataset" or the Enron (legitimate) + Nazario (phishing)
corpora, then run:
```bash
python train.py --data path/to/your.csv
```
Labels such as `Phishing Email`, `Safe Email`, `ham`, `1`, `0` are normalised automatically.
Expect lower accuracy on real data (typically 95-99% depending on the corpus).

## Files
- `features.py` – URL/keyword feature extraction + `explain()` red-flag reporter
- `generate_dataset.py` – synthetic data generator
- `train.py` – training, model selection, evaluation, plots
- `predict.py` – CLI inference with probabilities and red flags

## Limitations / ideas
- Ignores headers (SPF/DKIM, Reply-To mismatch) and attachments - adding these would help a lot.
- Does not follow redirects or check domain age / blocklists.
- Try `TfidfVectorizer(analyzer="char_wb")`, gradient boosting, or fine-tuned transformers.
