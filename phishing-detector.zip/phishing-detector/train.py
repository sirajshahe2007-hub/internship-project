"""Train, compare and evaluate phishing classifiers. Saves best model + confusion matrix."""
import argparse

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score, classification_report,
                             confusion_matrix)
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from features import EmailFeatures


def make_pipeline(clf):
    features = ColumnTransformer([
        # words + bigrams from the email text
        ("tfidf", TfidfVectorizer(lowercase=True, ngram_range=(1, 2), min_df=2,
                                  max_features=20000, sublinear_tf=True), "text"),
        # URL / keyword / style features
        ("handcrafted", Pipeline([("f", EmailFeatures()), ("scale", StandardScaler())]), "text"),
    ])
    return Pipeline([("features", features), ("clf", clf)])


def main(args):
    df = pd.read_csv(args.data).dropna(subset=["text", "label"])
    df["label"] = df["label"].astype(str).str.strip()
    # accept common label variants from public datasets
    df["label"] = df["label"].replace({"Phishing Email": "Phishing", "phishing": "Phishing", "1": "Phishing",
                                       "Safe Email": "Safe", "safe": "Safe", "ham": "Safe", "legitimate": "Safe", "0": "Safe"})
    print(f"Loaded {len(df)} emails:\n{df['label'].value_counts().to_string()}\n")

    X_train, X_test, y_train, y_test = train_test_split(
        df[["text"]], df["label"], test_size=0.2, stratify=df["label"], random_state=42)

    candidates = {
        "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(n_estimators=300, n_jobs=-1, random_state=42,
                                                class_weight="balanced"),
    }

    best_name, best_model, best_cv = None, None, -1
    for name, clf in candidates.items():
        pipe = make_pipeline(clf)
        cv = cross_val_score(pipe, X_train, y_train, cv=5, scoring="f1_macro").mean()
        print(f"{name:20s} 5-fold CV macro-F1 (train only): {cv:.4f}")
        if cv > best_cv:
            best_name, best_model, best_cv = name, pipe, cv

    print(f"\nSelected: {best_name}")
    best_model.fit(X_train, y_train)
    pred = best_model.predict(X_test)

    labels = ["Safe", "Phishing"]
    acc = accuracy_score(y_test, pred)
    print(f"\nTest accuracy: {acc:.4f}\n")
    print("Confusion matrix (rows = actual, cols = predicted):")
    print(pd.DataFrame(confusion_matrix(y_test, pred, labels=labels),
                       index=[f"actual {l}" for l in labels],
                       columns=[f"pred {l}" for l in labels]).to_string(), "\n")
    print(classification_report(y_test, pred, labels=labels, digits=4))

    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    ConfusionMatrixDisplay.from_predictions(y_test, pred, labels=labels, cmap="Blues", ax=ax)
    ax.set_title(f"{best_name}\nAccuracy: {acc:.2%}")
    plt.tight_layout()
    plt.savefig("outputs/confusion_matrix.png", dpi=150)

    joblib.dump(best_model, "models/phishing_model.joblib")
    print("Saved model -> models/phishing_model.joblib")
    print("Saved plot  -> outputs/confusion_matrix.png")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/emails.csv", help="CSV with columns: text,label")
    main(ap.parse_args())
