"""Hand-crafted URL and keyword features for phishing email detection."""
import re
from urllib.parse import urlparse

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

URL_RE = re.compile(r"(?:https?://|www\.)[^\s<>\"')]+", re.I)
IP_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")

SHORTENERS = {"bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd", "cutt.ly", "rebrand.ly"}
SUSPICIOUS_TLDS = {"xyz", "top", "click", "info", "biz", "tk", "ml", "ga", "cf", "gq", "work", "link", "support"}
BRANDS = ["paypal", "amazon", "apple", "microsoft", "netflix", "google", "bank", "dhl", "fedex", "irs"]

URGENCY_WORDS = [
    "urgent", "immediately", "suspended", "verify", "confirm", "expire", "expires", "limited time",
    "act now", "final notice", "within 24 hours", "locked", "unauthorized", "alert", "warning",
]
CREDENTIAL_WORDS = ["password", "login", "log in", "sign in", "username", "ssn", "social security",
                    "credit card", "card number", "pin", "account number", "bank details"]
MONEY_WORDS = ["winner", "prize", "lottery", "reward", "refund", "inheritance", "gift card", "claim", "$"]

FEATURE_NAMES = [
    "num_urls", "num_unique_domains", "has_ip_url", "has_shortener", "has_suspicious_tld",
    "has_at_symbol_url", "max_url_length", "max_subdomains", "max_hyphens_in_domain",
    "non_https_ratio", "brand_in_domain", "num_urgency_words", "num_credential_words",
    "num_money_words", "num_exclamations", "uppercase_ratio", "text_length", "has_html_tags",
]


def extract_urls(text: str):
    return [u.rstrip(".,;:!?") for u in URL_RE.findall(text or "")]


def _domain(url: str) -> str:
    if not url.lower().startswith("http"):
        url = "http://" + url
    return (urlparse(url).hostname or "").lower()


def _count(text_lower: str, words) -> int:
    return sum(text_lower.count(w) for w in words)


def compute_features(text: str) -> list:
    text = text or ""
    low = text.lower()
    urls = extract_urls(text)
    domains = [_domain(u) for u in urls]

    tlds = [d.rsplit(".", 1)[-1] for d in domains if "." in d]
    brand_hit = any(b in d for d in domains for b in BRANDS)
    letters = [c for c in text if c.isalpha()]

    return [
        len(urls),
        len(set(domains)),
        int(any(IP_RE.match(d) for d in domains)),
        int(any(d in SHORTENERS for d in domains)),
        int(any(t in SUSPICIOUS_TLDS for t in tlds)),
        int(any("@" in u.split("//", 1)[-1].split("/")[0] for u in urls)),
        max((len(u) for u in urls), default=0),
        max((d.count(".") for d in domains), default=0),
        max((d.count("-") for d in domains), default=0),
        (sum(not u.lower().startswith("https") for u in urls) / len(urls)) if urls else 0.0,
        int(brand_hit),
        _count(low, URGENCY_WORDS),
        _count(low, CREDENTIAL_WORDS),
        _count(low, MONEY_WORDS),
        text.count("!"),
        (sum(c.isupper() for c in letters) / len(letters)) if letters else 0.0,
        len(text),
        int(bool(re.search(r"<\s*(a|html|form|input)\b", low))),
    ]


def explain(text: str):
    """Return human-readable red flags found in an email."""
    f = dict(zip(FEATURE_NAMES, compute_features(text)))
    flags = []
    if f["has_ip_url"]:
        flags.append("Link points to a raw IP address")
    if f["has_shortener"]:
        flags.append("Uses a URL shortener that hides the real destination")
    if f["has_suspicious_tld"]:
        flags.append("Link uses a TLD commonly abused in phishing")
    if f["has_at_symbol_url"]:
        flags.append("URL contains '@' (can disguise the real host)")
    if f["brand_in_domain"] and f["max_hyphens_in_domain"] >= 1:
        flags.append("Brand name inside a hyphenated look-alike domain")
    if f["max_subdomains"] >= 3:
        flags.append("Unusually many subdomains in a link")
    if f["non_https_ratio"] > 0:
        flags.append("Contains non-HTTPS links")
    if f["num_urgency_words"] >= 2:
        flags.append("Urgent / threatening language")
    if f["num_credential_words"] >= 1:
        flags.append("Asks for credentials or sensitive details")
    if f["num_money_words"] >= 2:
        flags.append("Money / prize language")
    return flags


class EmailFeatures(BaseEstimator, TransformerMixin):
    """sklearn transformer: Series of raw email text -> numeric feature matrix."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([compute_features(t) for t in X], dtype=float)

    def get_feature_names_out(self, input_features=None):
        return np.array(FEATURE_NAMES)
