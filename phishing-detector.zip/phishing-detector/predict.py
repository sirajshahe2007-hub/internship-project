"""Classify an email as Phishing or Safe using the trained model.

Usage:
    python predict.py --text "Your account is suspended, verify at http://x.top/login"
    python predict.py --file email.txt
    python predict.py            # interactive: paste an email, end with an empty line
"""
import argparse
import sys

import joblib
import pandas as pd

from features import explain, extract_urls


def classify(model, text):
    proba = model.predict_proba(pd.DataFrame({"text": [text]}))[0]
    classes = list(model.classes_)
    label = classes[proba.argmax()]
    return label, dict(zip(classes, proba))


def show(model, text):
    label, probs = classify(model, text)
    icon = "🚨" if label == "Phishing" else "✅"
    print(f"\n{icon}  Verdict: {label}  (Phishing {probs.get('Phishing', 0):.1%} | Safe {probs.get('Safe', 0):.1%})")
    urls = extract_urls(text)
    if urls:
        print("URLs found:", *urls, sep="\n  - ")
    flags = explain(text)
    if flags:
        print("Red flags:", *flags, sep="\n  - ")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--text")
    ap.add_argument("--file")
    ap.add_argument("--model", default="models/phishing_model.joblib")
    a = ap.parse_args()

    model = joblib.load(a.model)
    if a.text:
        show(model, a.text)
    elif a.file:
        show(model, open(a.file, encoding="utf-8", errors="ignore").read())
    else:
        print("Paste an email, then press Enter on an empty line (Ctrl+C to quit):")
        while True:
            lines = []
            for line in sys.stdin:
                if not line.strip():
                    break
                lines.append(line)
            if not lines:
                break
            show(model, "".join(lines))
            print("\nPaste another email:")
