"""Generate a synthetic phishing/legitimate email dataset (data/emails.csv).

This is a stand-in so the project runs out of the box. For real-world results,
replace data/emails.csv with a real corpus (see README) that has `text,label` columns.
"""
import argparse
import random

import pandas as pd

BRANDS = ["PayPal", "Amazon", "Apple", "Microsoft", "Netflix", "Chase Bank", "DHL", "Google"]
FIRST = ["Alex", "Priya", "Sam", "Jordan", "Maria", "Chen", "Ravi", "Dana", "Lee", "Omar"]

# ---------- phishing ----------
def spoof_url(brand):
    b = brand.lower().replace(" ", "")
    return random.choice([
        f"http://{b}-secure-login.{random.choice(['xyz','top','click','info','tk'])}/verify",
        f"http://{b}.account-update.{random.choice(['com','net','biz'])}/signin?id={random.randint(1000,9999)}",
        f"http://{random.randint(11,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}/{b}/login",
        f"https://bit.ly/{random.choice(['3xYz','2aBc','4kLm'])}{random.randint(10,99)}",
        f"http://secure.{b}.com.verify-user.{random.choice(['top','work','link'])}/auth",
        f"http://{b}@{random.randint(11,223)}.{random.randint(0,255)}.1.{random.randint(1,254)}/",
    ])

PHISH_TEMPLATES = [
    ("Your {b} account has been suspended",
     "Dear customer, we detected unauthorized activity. Your account is locked. "
     "Verify your password immediately: {u} or it will be permanently closed within 24 hours."),
    ("URGENT: Action required on your {b} account",
     "Final notice! Confirm your login details now to avoid suspension. Click here: {u}. "
     "Failure to act will result in loss of access."),
    ("You have won a {b} gift card!",
     "Congratulations winner!!! You were selected for a $500 prize. Claim your reward now: {u}. "
     "Limited time offer, enter your card number to receive it."),
    ("Invoice #{n} - payment overdue",
     "Your payment is overdue. Open the attached invoice and sign in to confirm your bank details: {u}. "
     "Act now to avoid penalties."),
    ("Security alert: password expires today",
     "Your {b} password expires in 24 hours. Update your credentials immediately at {u} to keep your account active."),
    ("Package delivery failed",
     "We could not deliver your parcel. Confirm your address and pay a small fee here: {u}. Warning: item returned if not paid."),
    ("Refund pending - {b}",
     "You are eligible for a refund of $%d. Provide your account number and social security number at {u} to claim." % 240,
    ),
]
# harder phishing: no link, or polite tone
PHISH_HARD = [
    ("Quick favor", "Hi, are you available? I need you to buy gift cards for a client and send me the codes. I'm in a meeting, can't call. Reply urgently."),
    ("Payroll update", "Please reply with your bank details and account number so we can update your direct deposit before Friday."),
    ("Account notice", "Your {b} account may be at risk. Please confirm your username and password by replying to this email."),
    ("Your mailbox is full", "Your mailbox quota is exceeded. Log in at {u} to keep receiving mail."),
]

# ---------- legitimate ----------
LEGIT_URLS = ["https://github.com/{x}/repo/pull/{n}", "https://www.google.com/calendar/event?eid={n}",
              "https://docs.company.com/wiki/page{n}", "https://www.amazon.com/gp/css/order-details?orderId={n}",
              "https://www.linkedin.com/in/{x}", "https://zoom.us/j/{n}", "https://www.paypal.com/myaccount/summary"]
LEGIT_TEMPLATES = [
    ("Meeting notes - {t}", "Hi team, attached are the notes from today's sync. Please review the action items before Thursday. Docs: {u}"),
    ("Lunch tomorrow?", "Hey {x}, want to grab lunch tomorrow around noon? There's a new place near the office."),
    ("Your order has shipped", "Thanks for your order. Your package is on its way and should arrive by Friday. Track it here: {u}"),
    ("Weekly newsletter", "This week: three new tutorials, a community spotlight, and upcoming events. Read more at {u}. Unsubscribe any time."),
    ("Pull request review requested", "{x} requested your review on a pull request. Take a look when you have a moment: {u}"),
    ("Project update", "The Q3 report draft is ready. I've incorporated the feedback from last week. Let me know if you have questions."),
    ("Calendar invite: {t}", "You're invited to {t}. Join using the link below at the scheduled time: {u}"),
    ("Receipt for your payment", "Thank you for your payment of $%d. A copy of your receipt is available in your account: {u}" % 49),
]
# harder legit: urgency words / links / exclamations
LEGIT_HARD = [
    ("Urgent: server maintenance tonight", "Please save your work. Maintenance starts at 10pm and the system will be unavailable for an hour. Details: {u}"),
    ("Please confirm your attendance!", "Hi all, kindly confirm your attendance for the offsite by Friday. Thanks! {u}"),
    ("Security notice from IT", "As a reminder, never share your password with anyone. IT will never ask for it. Read our policy: {u}"),
    ("Password changed", "Your password was changed successfully. If this wasn't you, contact support through the official app."),
    ("Happy birthday!!!", "Wishing you an amazing birthday {x}!!! Celebrate with the team cake at 3pm."),
]
NOISE = 0.02
TOPICS = ["Sprint planning", "Design review", "Budget sync", "Team offsite", "Onboarding"]


def fill(tpl, kind):
    subj, body = tpl
    brand = random.choice(BRANDS)
    x = random.choice(FIRST)
    u = spoof_url(brand) if kind == "phish" else random.choice(LEGIT_URLS)
    mapping = dict(b=brand, u=u.format(x=x.lower(), n=random.randint(1000, 99999)), n=random.randint(1000, 99999),
                   x=x, t=random.choice(TOPICS))
    out = []
    for s in (subj, body):
        for k, v in mapping.items():
            s = s.replace("{" + k + "}", str(v))
        out.append(s)
    return f"Subject: {out[0]}\n\n{out[1]}"


def build(n, seed):
    random.seed(seed)
    rows = []
    for i in range(n):
        phish = i % 2 == 0
        hard = random.random() < 0.18
        if phish:
            tpl = random.choice(PHISH_HARD if hard else PHISH_TEMPLATES)
        else:
            tpl = random.choice(LEGIT_HARD if hard else LEGIT_TEMPLATES)
        text = fill(tpl, "phish" if phish else "legit")
        # light noise so the classes overlap a bit
        if random.random() < 0.15:
            text += "\n\nSent from my phone."
        if random.random() < 0.10:
            text = text.replace("Dear customer,", "Hello,")
        # overlap: real newsletters use shorteners; compromised/legit-looking hosts carry phishing
        r = random.random()
        if not phish and r < 0.10:
            text += f"\n\nMore info: https://bit.ly/{random.randint(1000,9999)}"
        elif phish and r < 0.10:
            text = text.replace("http://", "https://").replace(".xyz", ".com").replace(".top", ".com")
        elif not phish and r < 0.16:
            text += "\n\nReminder: confirm your details by Friday, it's urgent!"
        label = "Phishing" if phish else "Safe"
        if random.random() < NOISE:  # annotation noise, as in real datasets
            label = "Safe" if label == "Phishing" else "Phishing"
        rows.append((text, label))
    df = pd.DataFrame(rows, columns=["text", "label"]).sample(frac=1, random_state=seed).reset_index(drop=True)
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=4000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="data/emails.csv")
    a = ap.parse_args()
    df = build(a.n, a.seed)
    df.to_csv(a.out, index=False)
    print(f"Wrote {len(df)} emails to {a.out}\n{df['label'].value_counts().to_string()}")
