import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scanner import banners, ports, versions


class Tests(unittest.TestCase):
    def test_parse_ports(self):
        self.assertEqual(ports.parse_ports("22,80,100-102"), [22, 80, 100, 101, 102])
        with self.assertRaises(ValueError):
            ports.parse_ports("0,70000")

    def test_identify(self):
        self.assertIn(("openssh", "8.9"), banners.identify("SSH-2.0-OpenSSH_8.9p1 Ubuntu"))
        self.assertIn(("apache", "2.4.49"), banners.identify("Server: Apache/2.4.49 (Unix)"))

    def test_version_compare(self):
        self.assertLess(versions.parse_version("2.4.9"), versions.parse_version("2.4.58"))

    def test_outdated_and_known_bad(self):
        f = versions.check_software("vsftpd", "2.3.4")
        self.assertEqual({x.severity for x in f}, {"Critical", "Medium"})
        self.assertEqual(versions.check_software("nginx", "1.27.0"), [])


if __name__ == "__main__":
    unittest.main()
