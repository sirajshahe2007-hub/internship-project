# VulnScan Mini

A small, dependency-free (Python 3.8+) vulnerability scanner for learning the basics of
vulnerability assessment. It checks **open ports / risky services**, **outdated software
versions** (via banners), **web configuration weaknesses**, and writes a **report**
(Markdown, JSON or HTML).

> **Legal / ethical note:** only scan systems you own or have written permission to test.
> The tool asks you to confirm authorisation for any non-local target.

## Quick start

```bash
# Terminal 1 - start the safe local practice lab
python demo_lab.py

# Terminal 2 - scan it
python vulnscan.py 127.0.0.1 -p 2121,2222,8080 -f all -o demo_report
# -> demo_report.md / .json / .html
```

Other examples:

```bash
python vulnscan.py 127.0.0.1                      # common ports
python vulnscan.py 192.168.1.10 -p 1-1024         # a range on your LAN
python vulnscan.py https://example.com --authorized --no-web
python -m unittest discover tests                 # run unit tests
```

## What it checks

| Area | Checks |
|---|---|
| Ports | Threaded TCP connect scan; flags Telnet, FTP, SMB, RDP, VNC, Redis, DB ports, etc. |
| Versions | Banner grabbing + regex fingerprints (OpenSSH, Apache, nginx, PHP, IIS, vsFTPd, ProFTPD, OpenSSL) compared against `data/version_db.json` |
| Web | Missing security headers, version disclosure, cookie flags, no HTTP->HTTPS redirect, directory listing, exposed `.git` / `.env` / `phpinfo` / `server-status` |
| TLS | Certificate validity/expiry, deprecated protocol versions |

## Project layout

```
vulnscan.py          CLI entry point
demo_lab.py          local fake-vulnerable targets (127.0.0.1 only)
scanner/ports.py     port scanning + risky-service rules
scanner/banners.py   banner grabbing + software fingerprints
scanner/versions.py  outdated-version logic
scanner/web.py       HTTP / TLS configuration checks
scanner/report.py    Markdown / JSON / HTML reports
data/version_db.json minimum versions + known-bad releases
tests/               unit tests
```

## Limitations (good discussion points for your write-up)

- Banners can be hidden or spoofed, so version detection yields false negatives/positives.
- The version database is tiny and static; real scanners use NVD/CVE feeds.
- TCP connect scan only (no SYN/UDP scanning); no authenticated checks.
- Compare your results with `nmap -sV` and OWASP ZAP to see what a mature tool finds.

## Ideas to extend

1. Pull CVEs live from the NVD API for detected versions.
2. Add UDP scanning and service-specific probes.
3. Add CVSS scoring and a risk-prioritised summary chart.
4. Scan multiple hosts / CIDR ranges and diff reports over time.
