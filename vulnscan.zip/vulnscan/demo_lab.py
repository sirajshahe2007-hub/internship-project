#!/usr/bin/env python3
"""A deliberately 'vulnerable-looking' local lab for testing VulnScan Mini safely.

Binds to 127.0.0.1 only. Nothing here is actually exploitable - it just serves
weak headers, fake banners and decoy files so the scanner has something to find.

    python demo_lab.py            # then in another terminal:
    python vulnscan.py 127.0.0.1 -p 2121,2222,8080 -f all
"""
import socketserver
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

HOST = "127.0.0.1"


class Web(BaseHTTPRequestHandler):
    server_version = "Apache/2.2.15 (CentOS)"
    sys_version = ""

    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path == "/.git/HEAD":
            body, ctype = b"ref: refs/heads/main\n", "text/plain"
        elif self.path == "/.env":
            body, ctype = b"DEBUG=true\nSECRET_KEY=demo-not-real\n", "text/plain"
        elif self.path == "/":
            body, ctype = b"<html><body><h1>Demo lab</h1></body></html>", "text/html"
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("X-Powered-By", "PHP/5.3.3")
        self.send_header("Set-Cookie", "sessionid=abc123; Path=/")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def banner_server(port, banner):
    class H(socketserver.BaseRequestHandler):
        def handle(self):
            self.request.sendall(banner)

    srv = socketserver.ThreadingTCPServer((HOST, port), H)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()


if __name__ == "__main__":
    banner_server(2121, b"220 (vsFTPd 2.3.4)\r\n")
    banner_server(2222, b"SSH-2.0-OpenSSH_5.3\r\n")
    print(f"Demo lab on {HOST}: FTP-banner:2121  SSH-banner:2222  HTTP:8080  (Ctrl+C to stop)")
    try:
        HTTPServer((HOST, 8080), Web).serve_forever()
    except KeyboardInterrupt:
        pass
