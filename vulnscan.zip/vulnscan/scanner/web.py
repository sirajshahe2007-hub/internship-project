"""Basic web-application configuration checks (read-only GET requests)."""
import http.client
import socket
import ssl
import time
from urllib.parse import urlparse

from .models import Finding

UA = "VulnScanMini/1.0 (educational scanner)"

SECURITY_HEADERS = [
    ("strict-transport-security", "Medium", "HSTS header missing",
     "Browsers may connect over plain HTTP, enabling downgrade attacks.",
     "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains"),
    ("content-security-policy", "Medium", "Content-Security-Policy header missing",
     "No CSP means weaker protection against XSS and data injection.",
     "Define a restrictive Content-Security-Policy."),
    ("x-frame-options", "Low", "Clickjacking protection missing",
     "The page can be embedded in a malicious frame.",
     "Add X-Frame-Options: DENY (or CSP frame-ancestors)."),
    ("x-content-type-options", "Low", "X-Content-Type-Options missing",
     "Browsers may MIME-sniff responses.", "Add: X-Content-Type-Options: nosniff"),
    ("referrer-policy", "Low", "Referrer-Policy missing",
     "URLs may leak to third parties via the Referer header.",
     "Add: Referrer-Policy: strict-origin-when-cross-origin"),
]

# (path, matcher(status, body), severity, title, detail, fix)
SENSITIVE_PATHS = [
    ("/.git/HEAD", lambda s, b: s == 200 and b.startswith(b"ref:"), "High",
     "Exposed .git repository", "Source code and history may be downloadable.",
     "Block access to dotfiles/.git at the web server."),
    ("/.env", lambda s, b: s == 200 and b"=" in b and b"<html" not in b.lower(), "High",
     "Exposed .env file", "Environment files often contain secrets and credentials.",
     "Remove from web root and rotate any exposed secrets."),
    ("/phpinfo.php", lambda s, b: s == 200 and b"phpinfo()" in b, "Medium",
     "phpinfo() page exposed", "Reveals PHP configuration and server details.",
     "Delete the file."),
    ("/server-status", lambda s, b: s == 200 and b"Apache Server Status" in b, "Medium",
     "Apache server-status exposed", "Leaks request and server internals.",
     "Restrict to localhost/admin IPs."),
]


def _request(url, method="GET", timeout=5.0):
    p = urlparse(url)
    port = p.port or (443 if p.scheme == "https" else 80)
    path = (p.path or "/") + (f"?{p.query}" if p.query else "")
    if p.scheme == "https":
        conn = http.client.HTTPSConnection(p.hostname, port, timeout=timeout,
                                           context=ssl._create_unverified_context())
    else:
        conn = http.client.HTTPConnection(p.hostname, port, timeout=timeout)
    try:
        conn.request(method, path, headers={"User-Agent": UA})
        r = conn.getresponse()
        return r.status, r.getheaders(), r.read(65536)
    finally:
        conn.close()


def check_tls(host, port, timeout=5.0):
    target = f"{host}:{port}"
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                cert, version = ss.getpeercert(), ss.version()
    except ssl.SSLCertVerificationError as e:
        return [Finding("Medium", "TLS", "Certificate failed validation", str(e.verify_message),
                        "Install a valid certificate from a trusted CA.", target)]
    except (ssl.SSLError, OSError):
        return []
    out = []
    days = (ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) / 86400
    if days < 0:
        out.append(Finding("High", "TLS", "Certificate expired", f"Expired {-int(days)} days ago.",
                           "Renew the certificate.", target))
    elif days < 30:
        out.append(Finding("Low", "TLS", "Certificate expiring soon", f"Expires in {int(days)} days.",
                           "Renew the certificate.", target))
    if version in ("TLSv1", "TLSv1.1"):
        out.append(Finding("Medium", "TLS", f"Weak protocol negotiated: {version}",
                           "Deprecated TLS versions are vulnerable to known attacks.",
                           "Require TLS 1.2 or newer.", target))
    return out


def scan_url(url, timeout=5.0):
    """Return (findings, list_of_header_strings_for_version_detection)."""
    findings, banners = [], []
    p = urlparse(url)
    try:
        status, headers, body = _request(url, timeout=timeout)
    except (OSError, ssl.SSLError, http.client.HTTPException) as e:
        return [Finding("Info", "Web", "Web service unreachable", str(e), "", url)], banners

    h = {}
    for k, v in headers:
        h.setdefault(k.lower(), v)

    for key, sev, title, detail, fix in SECURITY_HEADERS:
        if key == "strict-transport-security" and p.scheme != "https":
            continue
        if key == "x-frame-options" and "frame-ancestors" in h.get("content-security-policy", ""):
            continue
        if key not in h:
            findings.append(Finding(sev, "Web Config", title, detail, fix, url))

    for key in ("server", "x-powered-by", "x-aspnet-version"):
        if key in h:
            banners.append(h[key])
            findings.append(Finding(
                "Low", "Info Disclosure", f"{key} header reveals technology: {h[key]}",
                "Version details help attackers pick targeted exploits.",
                "Suppress or genericise version info in server config.", url))

    for k, v in headers:
        if k.lower() != "set-cookie":
            continue
        name = v.split("=", 1)[0]
        low = v.lower()
        missing = [flag for flag, token in (("Secure", "secure"), ("HttpOnly", "httponly"),
                                             ("SameSite", "samesite")) if token not in low]
        if p.scheme != "https":
            missing = [m for m in missing if m != "Secure"]
        if missing:
            findings.append(Finding("Medium" if "HttpOnly" in missing else "Low", "Cookies",
                                    f"Cookie '{name}' missing {', '.join(missing)}",
                                    "Weak cookie flags raise the risk of theft or CSRF.",
                                    "Set Secure; HttpOnly; SameSite=Lax (or Strict).", url))

    if b"Index of /" in body[:2000]:
        findings.append(Finding("Medium", "Web Config", "Directory listing enabled",
                                "Visitors can browse files on the server.",
                                "Disable autoindex/Options -Indexes.", url))

    if p.scheme == "http" and not (300 <= status < 400
                                   and h.get("location", "").startswith("https://")):
        findings.append(Finding("Medium", "Web Config", "HTTP does not redirect to HTTPS",
                                "Traffic may be served unencrypted.",
                                "Redirect all HTTP traffic to HTTPS.", url))

    base = f"{p.scheme}://{p.netloc}"
    for path, matcher, sev, title, detail, fix in SENSITIVE_PATHS:
        try:
            s, _, b = _request(base + path, timeout=timeout)
        except (OSError, ssl.SSLError, http.client.HTTPException):
            continue
        if matcher(s, b):
            findings.append(Finding(sev, "Exposed Resource", title, detail, fix, base + path))

    if p.scheme == "https":
        findings += check_tls(p.hostname, p.port or 443, timeout)
    return findings, banners
