"""Banner grabbing and software/version identification."""
import re
import socket
import ssl

HTTP_PORTS = {80, 8000, 8080, 8888}
TLS_PORTS = {443, 8443}

SIGNATURES = [
    ("openssh", re.compile(r"OpenSSH[_-]([\d.]+)", re.I)),
    ("apache", re.compile(r"Apache/([\d.]+)", re.I)),
    ("nginx", re.compile(r"nginx/([\d.]+)", re.I)),
    ("vsftpd", re.compile(r"vsFTPd ([\d.]+)", re.I)),
    ("proftpd", re.compile(r"ProFTPD ([\d.]+)", re.I)),
    ("php", re.compile(r"PHP/([\d.]+)", re.I)),
    ("iis", re.compile(r"Microsoft-IIS/([\d.]+)", re.I)),
    ("openssl", re.compile(r"OpenSSL/([\d.]+)", re.I)),
]


def grab_banner(host, port, timeout=2.0):
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        sock.settimeout(timeout)
        if port in TLS_PORTS:
            ctx = ssl._create_unverified_context()
            sock = ctx.wrap_socket(sock, server_hostname=host)
        if port in HTTP_PORTS or port in TLS_PORTS:
            sock.sendall(f"HEAD / HTTP/1.0\r\nHost: {host}\r\n\r\n".encode())
        data = sock.recv(1024)
        sock.close()
        return data.decode(errors="replace").strip()
    except (OSError, ssl.SSLError):
        return ""


def identify(text):
    """Return a list of unique (product, version) pairs found in text."""
    found = []
    for product, rx in SIGNATURES:
        for m in rx.finditer(text or ""):
            pair = (product, m.group(1))
            if pair not in found:
                found.append(pair)
    return found
