"""VulnScan Mini - an educational vulnerability assessment toolkit."""
__version__ = "1.0.0"
