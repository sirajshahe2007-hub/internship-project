from dataclasses import dataclass, asdict

SEVERITIES = ["Info", "Low", "Medium", "High", "Critical"]
SEV_ORDER = {s: i for i, s in enumerate(SEVERITIES)}


@dataclass
class Finding:
    severity: str      # one of SEVERITIES
    category: str      # e.g. "Open Port", "Outdated Software", "Web Config", "TLS"
    title: str
    detail: str
    remediation: str
    target: str = ""

    def to_dict(self):
        return asdict(self)
