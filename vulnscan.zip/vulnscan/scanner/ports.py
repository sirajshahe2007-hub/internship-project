"""Threaded TCP connect scanner + risky-service rules."""
import socket
from concurrent.futures import ThreadPoolExecutor

from .models import Finding

COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP",
    110: "POP3", 111: "RPCbind", 135: "MSRPC", 139: "NetBIOS", 143: "IMAP",
    443: "HTTPS", 445: "SMB", 993: "IMAPS", 995: "POP3S", 1433: "MSSQL",
    1521: "Oracle", 2049: "NFS", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
    5900: "VNC", 6379: "Redis", 8080: "HTTP-alt", 8443: "HTTPS-alt",
    9200: "Elasticsearch", 11211: "Memcached", 27017: "MongoDB",
}

# port -> (severity, why it matters, fix)
RISKY = {
    21: ("Medium", "FTP sends credentials and data in cleartext.",
         "Use SFTP/FTPS, or restrict access with a firewall."),
    23: ("High", "Telnet is unencrypted and trivially sniffed.",
         "Disable Telnet and use SSH."),
    111: ("Medium", "RPCbind can leak information about running services.",
          "Block externally unless NFS/NIS is required."),
    135: ("Medium", "MSRPC exposure aids Windows enumeration.", "Block at the perimeter."),
    139: ("Medium", "NetBIOS exposure aids enumeration.", "Block at the perimeter."),
    445: ("High", "SMB exposed to the network has a long history of critical flaws.",
          "Block at the perimeter; keep patched; disable SMBv1."),
    1433: ("Medium", "Database port reachable from the network.", "Bind to localhost/VPN only."),
    1521: ("Medium", "Database port reachable from the network.", "Bind to localhost/VPN only."),
    2049: ("Medium", "NFS exposed; misconfigured exports leak files.", "Restrict exports by host."),
    3306: ("Medium", "Database port reachable from the network.", "Bind to localhost/VPN only."),
    3389: ("High", "RDP is a prime brute-force and exploit target.",
           "Put behind a VPN/gateway, enforce MFA and NLA."),
    5432: ("Medium", "Database port reachable from the network.", "Bind to localhost/VPN only."),
    5900: ("High", "VNC often has weak or no authentication.", "Tunnel over SSH/VPN."),
    6379: ("High", "Redis has no auth by default.", "Bind to localhost, set requirepass/ACLs."),
    9200: ("High", "Elasticsearch often runs without auth.", "Enable security; restrict access."),
    11211: ("High", "Memcached exposure enables data leaks and DDoS amplification.",
            "Bind to localhost; disable UDP."),
    27017: ("High", "MongoDB frequently deployed without auth.", "Enable auth; bind to localhost."),
}


def parse_ports(spec: str):
    """'top' | '1-1024' | '22,80,8000-8100' -> sorted list of ints."""
    spec = spec.strip().lower()
    if spec == "top":
        return sorted(COMMON_PORTS)
    ports = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            lo, hi = part.split("-", 1)
            ports.update(range(int(lo), int(hi) + 1))
        elif part:
            ports.add(int(part))
    if not ports or min(ports) < 1 or max(ports) > 65535:
        raise ValueError("ports must be within 1-65535")
    return sorted(ports)


def _is_open(host, port, timeout):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def scan_ports(host, ports, timeout=1.0, threads=100):
    with ThreadPoolExecutor(max_workers=threads) as pool:
        results = pool.map(lambda p: (p, _is_open(host, p, timeout)), ports)
    return sorted(p for p, ok in results if ok)


def port_findings(host, open_ports):
    findings = []
    for port in open_ports:
        svc = COMMON_PORTS.get(port, "unknown")
        findings.append(Finding(
            "Info", "Open Port", f"Port {port}/tcp open ({svc})",
            f"{host} accepts TCP connections on port {port}.",
            "Close the port if the service is not needed.", f"{host}:{port}"))
        if port in RISKY:
            sev, why, fix = RISKY[port]
            findings.append(Finding(sev, "Risky Service", f"{svc} exposed on port {port}",
                                    why, fix, f"{host}:{port}"))
    return findings
