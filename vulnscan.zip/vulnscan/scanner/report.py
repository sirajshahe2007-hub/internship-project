"""Report generation: Markdown, JSON, HTML."""
import html
import json
from collections import Counter
from datetime import datetime

from .models import SEV_ORDER, SEVERITIES

COLORS = {"Critical": "#7f1d1d", "High": "#dc2626", "Medium": "#d97706",
          "Low": "#2563eb", "Info": "#6b7280"}


def _sorted(findings):
    return sorted(findings, key=lambda f: -SEV_ORDER[f.severity])


def summary(findings):
    c = Counter(f.severity for f in findings)
    return {s: c.get(s, 0) for s in reversed(SEVERITIES)}


def build_meta(ports_scanned, open_ports):
    return {"generated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "ports_scanned": ports_scanned, "open_ports": open_ports}


def to_json(target, findings, meta):
    return json.dumps({"target": target, "meta": meta, "summary": summary(findings),
                       "findings": [f.to_dict() for f in _sorted(findings)]}, indent=2)


def to_markdown(target, findings, meta):
    lines = [f"# Vulnerability Scan Report: {target}", "",
             f"- **Generated:** {meta['generated']}",
             f"- **Ports scanned:** {meta['ports_scanned']}",
             f"- **Open ports:** {', '.join(map(str, meta['open_ports'])) or 'none'}", "",
             "## Summary", "", "| Severity | Count |", "|---|---|"]
    lines += [f"| {s} | {n} |" for s, n in summary(findings).items()]
    lines += ["", "## Findings", ""]
    for i, f in enumerate(_sorted(findings), 1):
        lines += [f"### {i}. [{f.severity}] {f.title}", "",
                  f"- **Category:** {f.category}", f"- **Target:** `{f.target}`",
                  f"- **Detail:** {f.detail}", f"- **Fix:** {f.remediation}", ""]
    lines += ["---", "*Automated results can include false positives/negatives. "
              "Verify manually before acting.*"]
    return "\n".join(lines)


def to_html(target, findings, meta):
    e = html.escape
    badges = "".join(
        f'<span class="b" style="background:{COLORS[s]}">{s}: {n}</span>'
        for s, n in summary(findings).items())
    rows = "".join(
        f'<tr><td><span class="b" style="background:{COLORS[f.severity]}">{f.severity}</span></td>'
        f"<td>{e(f.category)}</td><td><b>{e(f.title)}</b><br><small>{e(f.detail)}</small></td>"
        f"<td><code>{e(f.target)}</code></td><td>{e(f.remediation)}</td></tr>"
        for f in _sorted(findings))
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>Vulnerability Report - {e(target)}</title>
<style>body{{font-family:system-ui,sans-serif;margin:2rem;color:#111}}
table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ddd;padding:8px;vertical-align:top;text-align:left}}
th{{background:#f3f4f6}}.b{{color:#fff;padding:2px 8px;border-radius:4px;font-size:.85em;margin-right:6px}}
code{{background:#f3f4f6;padding:1px 4px}}</style></head><body>
<h1>Vulnerability Scan Report</h1>
<p><b>Target:</b> {e(target)}<br><b>Generated:</b> {e(meta['generated'])}<br>
<b>Open ports:</b> {e(', '.join(map(str, meta['open_ports'])) or 'none')}</p>
<p>{badges}</p>
<table><tr><th>Severity</th><th>Category</th><th>Finding</th><th>Target</th><th>Remediation</th></tr>
{rows}</table>
<p><small>Automated results can include false positives/negatives. Verify manually.</small></p>
</body></html>"""
