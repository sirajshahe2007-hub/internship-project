"""Compare detected software versions against a small local database."""
import json
import re
from pathlib import Path

from .models import Finding

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "version_db.json"


def load_db(path=DB_PATH):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def parse_version(v):
    return tuple(int(x) for x in re.findall(r"\d+", v))


def check_software(product, version, target="", db=None):
    db = db or load_db()
    findings = []

    bad = db.get("known_bad", {}).get(product, {}).get(version)
    if bad:
        findings.append(Finding(
            "Critical", "Outdated Software", f"{product} {version} has a known serious flaw",
            bad, f"Upgrade {product} immediately.", target))

    rule = db.get("min_versions", {}).get(product)
    if rule and parse_version(version) < parse_version(rule["min"]):
        findings.append(Finding(
            "High" if not bad else "Medium", "Outdated Software",
            f"Outdated {product} {version} (recommended >= {rule['min']})",
            rule["why"], f"Upgrade {product} to a supported, patched release.", target))
    return findings
