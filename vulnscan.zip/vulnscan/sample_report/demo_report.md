# Vulnerability Scan Report: 127.0.0.1

- **Generated:** 2026-11-25 10:36:01
- **Ports scanned:** 3
- **Open ports:** 2121, 2222, 8080

## Summary

| Severity | Count |
|---|---|
| Critical | 1 |
| High | 6 |
| Medium | 4 |
| Low | 5 |
| Info | 3 |

## Findings

### 1. [Critical] vsftpd 2.3.4 has a known serious flaw

- **Category:** Outdated Software
- **Target:** `127.0.0.1:2121`
- **Detail:** CVE-2011-2523: this release shipped with a backdoor.
- **Fix:** Upgrade vsftpd immediately.

### 2. [High] Outdated openssh 5.3 (recommended >= 9.0)

- **Category:** Outdated Software
- **Target:** `127.0.0.1:2222`
- **Detail:** Older OpenSSH releases have multiple published vulnerabilities.
- **Fix:** Upgrade openssh to a supported, patched release.

### 3. [High] Outdated apache 2.2.15 (recommended >= 2.4.58)

- **Category:** Outdated Software
- **Target:** `127.0.0.1:8080`
- **Detail:** Older Apache httpd 2.4.x releases have fixed security issues.
- **Fix:** Upgrade apache to a supported, patched release.

### 4. [High] Exposed .git repository

- **Category:** Exposed Resource
- **Target:** `http://127.0.0.1:8080/.git/HEAD`
- **Detail:** Source code and history may be downloadable.
- **Fix:** Block access to dotfiles/.git at the web server.

### 5. [High] Exposed .env file

- **Category:** Exposed Resource
- **Target:** `http://127.0.0.1:8080/.env`
- **Detail:** Environment files often contain secrets and credentials.
- **Fix:** Remove from web root and rotate any exposed secrets.

### 6. [High] Outdated apache 2.2.15 (recommended >= 2.4.58)

- **Category:** Outdated Software
- **Target:** `http://127.0.0.1:8080`
- **Detail:** Older Apache httpd 2.4.x releases have fixed security issues.
- **Fix:** Upgrade apache to a supported, patched release.

### 7. [High] Outdated php 5.3.3 (recommended >= 8.2.0)

- **Category:** Outdated Software
- **Target:** `http://127.0.0.1:8080`
- **Detail:** Older PHP branches are end-of-life and receive no security fixes.
- **Fix:** Upgrade php to a supported, patched release.

### 8. [Medium] Outdated vsftpd 2.3.4 (recommended >= 3.0.3)

- **Category:** Outdated Software
- **Target:** `127.0.0.1:2121`
- **Detail:** Older vsftpd releases are unsupported.
- **Fix:** Upgrade vsftpd to a supported, patched release.

### 9. [Medium] Content-Security-Policy header missing

- **Category:** Web Config
- **Target:** `http://127.0.0.1:8080`
- **Detail:** No CSP means weaker protection against XSS and data injection.
- **Fix:** Define a restrictive Content-Security-Policy.

### 10. [Medium] Cookie 'sessionid' missing HttpOnly, SameSite

- **Category:** Cookies
- **Target:** `http://127.0.0.1:8080`
- **Detail:** Weak cookie flags raise the risk of theft or CSRF.
- **Fix:** Set Secure; HttpOnly; SameSite=Lax (or Strict).

### 11. [Medium] HTTP does not redirect to HTTPS

- **Category:** Web Config
- **Target:** `http://127.0.0.1:8080`
- **Detail:** Traffic may be served unencrypted.
- **Fix:** Redirect all HTTP traffic to HTTPS.

### 12. [Low] Clickjacking protection missing

- **Category:** Web Config
- **Target:** `http://127.0.0.1:8080`
- **Detail:** The page can be embedded in a malicious frame.
- **Fix:** Add X-Frame-Options: DENY (or CSP frame-ancestors).

### 13. [Low] X-Content-Type-Options missing

- **Category:** Web Config
- **Target:** `http://127.0.0.1:8080`
- **Detail:** Browsers may MIME-sniff responses.
- **Fix:** Add: X-Content-Type-Options: nosniff

### 14. [Low] Referrer-Policy missing

- **Category:** Web Config
- **Target:** `http://127.0.0.1:8080`
- **Detail:** URLs may leak to third parties via the Referer header.
- **Fix:** Add: Referrer-Policy: strict-origin-when-cross-origin

### 15. [Low] server header reveals technology: Apache/2.2.15 (CentOS) 

- **Category:** Info Disclosure
- **Target:** `http://127.0.0.1:8080`
- **Detail:** Version details help attackers pick targeted exploits.
- **Fix:** Suppress or genericise version info in server config.

### 16. [Low] x-powered-by header reveals technology: PHP/5.3.3

- **Category:** Info Disclosure
- **Target:** `http://127.0.0.1:8080`
- **Detail:** Version details help attackers pick targeted exploits.
- **Fix:** Suppress or genericise version info in server config.

### 17. [Info] Port 2121/tcp open (unknown)

- **Category:** Open Port
- **Target:** `127.0.0.1:2121`
- **Detail:** 127.0.0.1 accepts TCP connections on port 2121.
- **Fix:** Close the port if the service is not needed.

### 18. [Info] Port 2222/tcp open (unknown)

- **Category:** Open Port
- **Target:** `127.0.0.1:2222`
- **Detail:** 127.0.0.1 accepts TCP connections on port 2222.
- **Fix:** Close the port if the service is not needed.

### 19. [Info] Port 8080/tcp open (HTTP-alt)

- **Category:** Open Port
- **Target:** `127.0.0.1:8080`
- **Detail:** 127.0.0.1 accepts TCP connections on port 8080.
- **Fix:** Close the port if the service is not needed.

---
*Automated results can include false positives/negatives. Verify manually before acting.*