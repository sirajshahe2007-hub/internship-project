#!/usr/bin/env python3
"""VulnScan Mini - educational vulnerability scanner.

Only scan systems you own or have explicit written permission to test.
"""
import argparse
import ipaddress
import socket
import sys
from urllib.parse import urlparse

from scanner import banners, ports as portmod, report, versions, web

WEB_PORTS = {80, 8000, 8080, 8888, 443, 8443}
BANNER = "VulnScan Mini - for authorised testing only"


def resolve(target):
    """Accept 'host' or a full URL. Return (host, url_or_None)."""
    if "://" in target:
        p = urlparse(target)
        return p.hostname, target
    return target, None


def is_local(host):
    try:
        ip = ipaddress.ip_address(socket.gethostbyname(host))
    except (socket.gaierror, ValueError):
        return False
    return ip.is_loopback or ip.is_private


def confirm_authorised(host, flag):
    if flag or is_local(host):
        return True
    print(f"\n[!] {host} is not a loopback/private address.")
    print("    Scanning systems without permission may be illegal.")
    try:
        return input("    Type 'yes' to confirm you are authorised to scan it: ").strip().lower() == "yes"
    except EOFError:
        return False


def main(argv=None):
    ap = argparse.ArgumentParser(description=BANNER)
    ap.add_argument("target", help="hostname/IP or URL (e.g. 127.0.0.1 or http://localhost:8080)")
    ap.add_argument("-p", "--ports", default="top",
                    help="'top', '1-1024', or list like 22,80,8000-8100 (default: top)")
    ap.add_argument("-t", "--timeout", type=float, default=1.0, help="socket timeout (s)")
    ap.add_argument("--threads", type=int, default=100)
    ap.add_argument("--no-web", action="store_true", help="skip HTTP/TLS configuration checks")
    ap.add_argument("-o", "--output", help="report file base name (no extension)")
    ap.add_argument("-f", "--format", choices=["md", "json", "html", "all"], default="md")
    ap.add_argument("--authorized", action="store_true",
                    help="confirm you have permission to scan a non-local target")
    args = ap.parse_args(argv)

    host, url = resolve(args.target)
    if not host:
        ap.error("could not parse a host from target")
    if not confirm_authorised(host, args.authorized):
        print("Aborted: authorisation not confirmed.")
        return 2

    try:
        port_list = portmod.parse_ports(args.ports)
    except ValueError as e:
        ap.error(str(e))

    print(f"{BANNER}\n[*] Target: {host}  |  ports: {len(port_list)}")
    findings = []

    # 1. Port scan
    open_ports = portmod.scan_ports(host, port_list, args.timeout, args.threads)
    print(f"[+] Open ports: {open_ports or 'none'}")
    findings += portmod.port_findings(host, open_ports)

    # 2. Banner grabbing -> version checks
    db = versions.load_db()
    seen = set()

    def check_versions(text, where):
        for product, ver in banners.identify(text):
            if (product, ver, where) in seen:
                continue
            seen.add((product, ver, where))
            print(f"[+] Detected {product} {ver} @ {where}")
            findings.extend(versions.check_software(product, ver, where, db))

    for port in open_ports:
        check_versions(banners.grab_banner(host, port, args.timeout + 1), f"{host}:{port}")

    # 3. Web checks
    if not args.no_web:
        urls = [url] if url else []
        for port in open_ports:
            if port in WEB_PORTS:
                scheme = "https" if port in (443, 8443) else "http"
                candidate = f"{scheme}://{host}:{port}"
                if not url or urlparse(url).port != port:
                    urls.append(candidate)
        for u in urls:
            print(f"[*] Web checks: {u}")
            f, hdrs = web.scan_url(u, timeout=args.timeout + 4)
            findings += f
            for h in hdrs:
                check_versions(h, u)

    # 4. Report
    meta = report.build_meta(len(port_list), open_ports)
    s = report.summary(findings)
    print("\n=== Summary === " + "  ".join(f"{k}:{v}" for k, v in s.items()))

    base = args.output or f"report_{host.replace(':', '_')}"
    writers = {"md": report.to_markdown, "json": report.to_json, "html": report.to_html}
    for fmt in (writers if args.format == "all" else [args.format]):
        path = f"{base}.{fmt}"
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(writers[fmt](args.target, findings, meta))
        print(f"[+] Report written: {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
